import pandas as pd
import numpy as np
import random
import json
import matplotlib.pyplot as plt
import time
from lightgbm import LGBMRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split
from itertools import product

df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X = df[feature_cols].values
y = df['Hogprice'].values  #target variable

n_forecast = 42  # predict the last 42 days
start_forecast_index = len(df) - n_forecast

print("Starting the WAA hyperparameter search...")
init_train_df = df.iloc[:start_forecast_index].dropna(subset=feature_cols + ['Hogprice'])

X_init = init_train_df[feature_cols].values
y_init = init_train_df['Hogprice'].values

X_train_init, X_val_init, y_train_init, y_val_init = train_test_split(
    X_init, y_init, test_size=0.2, random_state=42
)

param_space = {
    "n_estimators": list(range(200, 1601, 100)),
    "learning_rate": [0.005, 0.01, 0.02, 0.03, 0.05, 0.07,0.08],
    "num_leaves": [8, 16, 32, 48, 64, 80, 100],
    "min_data_in_leaf": [5, 7, 10, 15, 20],
    "feature_fraction": [0.6, 0.7, 0.8, 0.9, 1.0],
    "bagging_fraction": [0.6, 0.7, 0.8, 0.9, 1.0],
    "bagging_freq": [0, 1, 2, 3, 4, 5]
}

param_keys = list(param_space.keys())
all_combinations = list(product(*param_space.values()))

population = random.sample(all_combinations, 8)
alpha = 15
no_improve_count = 0
best_score = float('inf')
best_params = None

start_time = time.time()
for gen in range(50):
    scored_population = []
    for individual in population:
        params = {k: v for k, v in zip(param_keys, individual)}
        params["objective"] = "regression"
        params["random_state"] = 42
        params["verbose"] = -1

        try:
            model = LGBMRegressor(**params)
            model.fit(X_train_init, y_train_init)
            preds = model.predict(X_val_init)
            mae = mean_absolute_error(y_val_init, preds)
            scored_population.append((individual, mae))

            if mae < best_score:
                best_score = mae
                best_params = params
                no_improve_count = 0
                print(f"🔥 Discover a new optimal MAE: {mae:.4f} | Parameters: {params}")
            else:
                no_improve_count += 1
        except Exception as e:
            print(f"⚠️ Parameter combination failure: {params} | Error: {str(e)}")
            scored_population.append((individual, float('inf')))
            no_improve_count += 1

    if no_improve_count >= alpha:
        print(f"✅ Early discontinuation: No improvement in the {gen + 1} generation")
        break

    scored_population.sort(key=lambda x: x[1])
    selected = [x[0] for x in scored_population[:5]]

    mutated = []
    while len(mutated) < 5:
        parent = list(random.choice(selected))
        idx = random.randint(0, len(parent) - 1)
        parent[idx] = random.choice(param_space[param_keys[idx]])
        mutated.append(tuple(parent))

    population = selected + mutated

with open("best_params_waa_lgbm.json", "w") as f:
    json.dump(best_params, f, indent=4)

elapsed_time = time.time() - start_time
print(f"✅ WAA search completed | Time consumption: {elapsed_time:.2f} seconds | Optimal MAE: {best_score:.4f}")
print(f"✅ The optimal parameters have been saved: best_params_waa_lgbm_expanding.json")

print("Starting expanding the window scrolling prediction...")
true_prices, pred_prices, pred_dates = [], [], []

for i in range(start_forecast_index, len(df)):
    train_df = df.iloc[:i]
    test_df = df.iloc[i:i + 1]

    X_train = train_df[feature_cols].values
    y_train = train_df['Hogprice'].values
    X_test = test_df[feature_cols].values
    y_test = test_df['Hogprice'].values[0]

    model = LGBMRegressor(**best_params)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)[0]

    pred_prices.append(pred)
    true_prices.append(y_test)
    pred_dates.append(test_df['date'].values[0])

    if (i - start_forecast_index + 1) % 5 == 0:
        print(f"Progress: {i - start_forecast_index + 1}/{n_forecast}")

true_prices = np.array(true_prices)
pred_prices = np.array(pred_prices)
print("\nModel evaluation results:")
print("R2:", r2_score(true_prices, pred_prices))
print("MAE:", mean_absolute_error(true_prices, pred_prices))
print("RMSE:", np.sqrt(mean_squared_error(true_prices, pred_prices)))
print("MAPE:", mean_absolute_percentage_error(true_prices, pred_prices))

plt.figure(figsize=(10, 5))
plt.plot(pred_dates, true_prices, label="True Price")
plt.plot(pred_dates, pred_prices, label="Predicted Price")
plt.title(f"LightGBM Forecast (Future {n_forecast} steps - WAA Optimized)")
plt.xlabel("Date")
plt.ylabel("Price")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("lgb_forecast_waa_optimized.png")
plt.show()

result_df = pd.DataFrame({
    "Date": pred_dates,
    "TruePrice": true_prices,
    "PredictedPrice": pred_prices,
    "AbsoluteError": np.abs(true_prices - pred_prices),
    "RelativeError(%)": np.abs(true_prices - pred_prices) / true_prices * 100
})
result_df.to_excel("lgb_forecast_results_waa_optimized.xlsx", index=False)
print("\nThe rolling prediction result of the extended window has been saved：lgb_forecast_results_waa_optimized.xlsx")

import json
with open("best_params_waa.json", "w") as f:
    json.dump(best_params, f, indent=4)
print("The optimal parameters have been saved as a JSON file：best_params_waa.json")
