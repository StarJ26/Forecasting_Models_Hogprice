import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from lightgbm import LGBMRegressor
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, mean_absolute_percentage_error


df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X = df[feature_cols].values
y = df['Hogprice'].values  #target variable

scaler_X = MinMaxScaler()
scaler_y = StandardScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.reshape(-1,1)).flatten()

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42, shuffle=False)

n_forecast = 42  # predict the last 42 days
start_forecast_index = len(df) - n_forecast
true_prices, pred_prices, shap_matrix, pred_dates = [], [], [], []

for i in range(start_forecast_index, len(df)):
    train_df = df.iloc[:i]
    test_df = df.iloc[i:i+1]

    X_train = train_df[feature_cols].values
    y_train = train_df['Hogprice'].values
    X_test = test_df[feature_cols].values
    y_test = test_df['Hogprice'].values[0]

    model = LGBMRegressor(
        objective='regression',
        random_state=42,
        n_estimators=2100,
        num_leaves=3,
        learning_rate=0.02,
        min_data_in_leaf=5,
        feature_fraction=0.9,
        bagging_fraction=0.9,
        bagging_freq=0,
        verbose=-1
    )

    model.fit(X_train, y_train)
    pred = model.predict(X_test)[0]

    pred_prices.append(pred)
    true_prices.append(y_test)
    pred_dates.append(test_df['date'].values[0])

true_prices = np.array(true_prices)
pred_prices = np.array(pred_prices)
print("R2:", r2_score(true_prices, pred_prices))
print("MAE:", mean_absolute_error(true_prices, pred_prices))
print("RMSE:", np.sqrt(mean_squared_error(true_prices, pred_prices)))
print("MAPE:", mean_absolute_percentage_error(true_prices, pred_prices))

plt.figure(figsize=(10, 5))
plt.plot(pred_dates, true_prices, label="True Price")
plt.plot(pred_dates, pred_prices, label="Predicted Price")
plt.title("LightGBM Forecast (Future 42 steps - Expanding Window)")
plt.xlabel("Date")
plt.ylabel("Price")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("lgb_forecast_expanding_window.png")
plt.show()

result_df = pd.DataFrame({
    "Date": pred_dates,
    "TruePrice": true_prices,
    "PredictedPrice": pred_prices,
    "AbsoluteError": np.abs(true_prices - pred_prices),
    "RelativeError(%)": np.abs(true_prices - pred_prices) / true_prices * 100
})
result_df.to_excel("lgb_forecast_results_expanding_window.xlsx", index=False)
