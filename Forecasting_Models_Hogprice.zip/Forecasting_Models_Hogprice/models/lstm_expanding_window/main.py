import time

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, mean_absolute_percentage_error
import wandb
import os

wandb.init(project="hog_price_forecasting", name="LSTM_Model", reinit=True)

df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X = df[feature_cols].values
y = df['Hogprice'].values  #target variable

scaler_X = MinMaxScaler()
scaler_y = StandardScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.reshape(-1,1)).flatten()

total_len = len(X)
train_len = int(total_len * 0.8)
test_len = total_len - train_len
test_start_idx = train_len

class LSTMModel(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim=1, dropout=0.2, lookback=1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lookback = lookback
        self.lstm = torch.nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True, dropout=dropout)
        self.fc = torch.nn.Linear(hidden_dim, output_dim)
        if lookback > 1:
            self.lookback_proj = torch.nn.Linear(lookback * input_dim, input_dim)

    def forward(self, x):
        if self.lookback > 1:
            batch_size = x.size(0)
            x = x.view(batch_size, self.lookback, -1)

        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x, (h0, c0))

        out = self.fc(out[:, -1, :])
        return out

def train_one_epoch(model, train_loader, optimizer, loss_fn, device):
    model.train()
    total_loss = 0
    for xb, yb in train_loader:
        xb, yb = xb.to(device), yb.to(device)

        # 前向传播
        pred = model(xb).squeeze()
        loss = loss_fn(pred, yb)

        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.5)
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(train_loader)

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Use the equipment: {device}")

    input_dim = X.shape[1]
    hidden_dim = 16
    num_layers = 1
    output_dim = 1
    batch_size = 16
    learning_rate = 0.012
    lookback = 3

    print("Starting expanding the window scrolling prediction..")
    start_time = time.time()

    history_X_raw = X[:train_len].tolist()
    history_y_raw = y[:train_len].tolist()

    pred_prices = []
    true_prices = []

    training_times = []

    epochs_per_step = 80

    for i in range(test_len):
        iter_start_time = time.time()

        X_train_raw = np.array(history_X_raw)
        y_train_raw = np.array(history_y_raw)

        scaler_X_current = MinMaxScaler()
        X_train_scaled = scaler_X_current.fit_transform(X_train_raw)

        scaler_Y_current = StandardScaler()
        y_train_scaled = scaler_Y_current.fit_transform(y_train_raw.reshape(-1, 1)).flatten()

        X_train_tensor = []
        y_train_tensor = []

        for j in range(lookback, len(X_train_scaled)):
            window = X_train_scaled[j - lookback:j].flatten()
            X_train_tensor.append(window)
            y_train_tensor.append(y_train_scaled[j])

        X_train_tensor = torch.tensor(np.array(X_train_tensor), dtype=torch.float32)
        y_train_tensor = torch.tensor(np.array(y_train_tensor), dtype=torch.float32)

        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=min(batch_size, len(train_dataset)), shuffle=True)

        model = LSTMModel(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            output_dim=output_dim,
            dropout=0,
            lookback=lookback
        ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        loss_fn = torch.nn.MSELoss()

        for epoch in range(epochs_per_step):
            train_loss = train_one_epoch(model, train_loader, optimizer, loss_fn, device)

        test_idx = test_start_idx + i
        if test_idx >= lookback:
            test_window = X[test_idx - lookback:test_idx].flatten()
        else:

            padding = np.tile(X[0], (lookback - test_idx, 1))
            available = X[:test_idx]
            test_window = np.vstack([padding, available]).flatten()

        test_X_raw = test_window.reshape(1, -1)

        test_X_reshaped = test_X_raw.reshape(lookback, -1)
        test_X_scaled = scaler_X_current.transform(test_X_reshaped)
        test_X_scaled_flattened = test_X_scaled.flatten().reshape(1, -1)


        with torch.no_grad():
            model.eval()
            test_input = torch.tensor(test_X_scaled_flattened, dtype=torch.float32).to(device)
            y_pred_scaled = model(test_input).item()

        y_pred = scaler_Y_current.inverse_transform([[y_pred_scaled]])[0][0]
        true_price = y[test_idx]

        pred_prices.append(y_pred)
        true_prices.append(true_price)

        history_X_raw.append(X[test_idx])
        history_y_raw.append(true_price)

        iter_time = time.time() - iter_start_time
        training_times.append(iter_time)

        if (i + 1) % 10 == 0 or i == test_len - 1:
            avg_time = np.mean(training_times[-10:]) if i >= 10 else iter_time
            remaining = (test_len - i - 1) * avg_time
            print(f" completed the {i + 1}/{test_len} step prediction -"
                  f" Training set size: {len(history_X_raw)} -"
                  f" Time consumption of this round: {iter_time:.2f}s -"
                  "Expected remaining: {remaining / 60:.1f} minutes")

    total_time = time.time() - start_time
    print(f" Rolling prediction completed! Total time consumption: {total_time / 60:.2f} minutes")

    r2 = r2_score(true_prices, pred_prices)
    mae = mean_absolute_error(true_prices, pred_prices)
    rmse = np.sqrt(mean_squared_error(true_prices, pred_prices))
    mape = mean_absolute_percentage_error(true_prices, pred_prices)

    print("\nModel evaluation results:")
    print(f"R²: {r2:.6f}")
    print(f"MAE: {mae:.6f}")
    print(f"RMSE: {rmse:.6f}")
    print(f"MAPE: {mape:.6f}")

    results = pd.DataFrame({
        'Date': df['Date'].iloc[test_start_idx:test_start_idx + test_len],
        'True_Price': true_prices,
        'Predicted_Price': pred_prices
    })
    results.to_csv("lstm_expanding_window_results.csv", index=False)
    print("The prediction results have been saved to lstm_expanding_window_results.csv")

