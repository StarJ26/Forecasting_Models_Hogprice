import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
import json
from lightgbm import LGBMRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.model_selection import TimeSeriesSplit

df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X = df[feature_cols].values
y = df['Hogprice'].values  #target variable

split_idx = int(len(df) * 0.8)
train_search_df = df.iloc[:split_idx].dropna(subset=feature_cols + ['Hogprice'])

X_search = train_search_df[feature_cols].values
y_search = train_search_df['Hogprice'].values

tscv = TimeSeriesSplit(n_splits=3)

param_dist = {
    "n_estimators": [300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500],
    "learning_rate": [0.009 ,0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1],
    "num_leaves": [2, 4, 6, 8, 16, 32,  64, 128, 256],
    "min_data_in_leaf": [1, 3, 5, 7, 9, 10],
    "feature_fraction": [0.6, 0.7, 0.8, 0.9, 1.0],
    "bagging_fraction": [0.6, 0.7, 0.8, 0.9, 1.0],
    "bagging_freq": [0, 1, 2, 3, 4, 5]
}

random_search = RandomizedSearchCV(
    estimator=LGBMRegressor(objective='regression', random_state=42, verbose=-1),
    param_distributions=param_dist,
    n_iter=30,
    scoring='neg_mean_absolute_error',
    cv=tscv,
    random_state=42,
    n_jobs=-1,
    verbose=1
)

print("Start the random search for optimization parameters...")
start_time = time.time()
random_search.fit(X_search, y_search)
search_time = time.time() - start_time

best_params = random_search.best_params_
best_params.update({"objective": "regression", "random_state": 42, "verbose": -1})
for param, value in best_params.items():
    print(f"{param}: {value}")
with open("best_params_lgbm.json", "w") as f:
    json.dump(best_params, f, indent=4)


n_forecast = 42  # predict the last 42 days
start_forecast_index = len(df) - n_forecast

true_prices, pred_prices, pred_dates = [], [], []

print(f"\nStart to expand the window rolling prediction ({n_forecast} at several time points)...")
for i in range(start_forecast_index, len(df)):
    train_df = df.iloc[:i]
    test_df = df.iloc[i:i + 1]
    train_df = train_df.dropna(subset=feature_cols + ['Hogprice'])

    X_train = train_df[feature_cols].values
    y_train = train_df['Hogprice'].values
    X_test = test_df[feature_cols].values
    y_test = test_df['Hogprice'].values[0]

    model = LGBMRegressor(**best_params)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)[0]

    pred_prices.append(pred)
    true_prices.append(y_test)
    pred_dates.append(test_df['date'].values[0])

    progress = (i - start_forecast_index + 1) / n_forecast * 100
    print(f"Completed: {i - start_forecast_index + 1}/{n_forecast} ({progress:.1f}%)")

true_prices = np.array(true_prices)
pred_prices = np.array(pred_prices)
print("\n===== Model evaluation results =====")
print("R2:", r2_score(true_prices, pred_prices))
print("MAE:", mean_absolute_error(true_prices, pred_prices))
print("RMSE:", np.sqrt(mean_squared_error(true_prices, pred_prices)))
print("MAPE:", mean_absolute_percentage_error(true_prices, pred_prices))


result_df = pd.DataFrame({
    "Date": pred_dates,
    "TruePrice": true_prices,
    "PredictedPrice": pred_prices,
    "AbsoluteError": np.abs(true_prices - pred_prices),
    "RelativeError(%)": np.abs(true_prices - pred_prices) / true_prices * 100
})
result_df.to_excel("lgb_forecast_results_expanding_window.xlsx", index=False)


plt.figure(figsize=(12, 6))
plt.plot(pred_dates, true_prices, 'o-', linewidth=2, markersize=6, label="True Price")
plt.plot(pred_dates, pred_prices, 's--', linewidth=2, markersize=6, label="Predicted Price")
plt.title(f"LightGBM Forecast (Expanding Window, R2={r2_score(true_prices, pred_prices):.4f})", fontsize=14)
plt.xlabel("Date", fontsize=12)
plt.ylabel("Price", fontsize=12)
plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.7)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("lgb_forecast_expanding_window.png", dpi=300)
plt.show()

print("The rolling prediction result of the extended window has been saved ：lgb_forecast_results_expanding_window.xlsx")