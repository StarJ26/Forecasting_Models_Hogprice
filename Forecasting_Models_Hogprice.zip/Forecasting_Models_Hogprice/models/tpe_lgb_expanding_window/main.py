import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import optuna
from lightgbm import LGBMRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split

df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X = df[feature_cols].values
y = df['Hogprice'].values  #target variable

n_forecast = 42  # predict the last 42 days
start_forecast_index = len(df) - n_forecast
initial_train_df = df.iloc[:start_forecast_index].copy()
X_search = initial_train_df[feature_cols].values
y_search = initial_train_df['Hogprice'].values
X_train_search, X_val_search, y_train_search, y_val_search = train_test_split(
    X_search, y_search, test_size=0.2, random_state=42
)

def objective(trial):
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 100, 1600, step=100),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.02, log=True),
        "num_leaves": trial.suggest_int("num_leaves", 2, 10),
        "min_data_in_leaf": trial.suggest_int("min_data_in_leaf", 1, 10),
        "feature_fraction": trial.suggest_float("feature_fraction", 0.5, 1.0),
        "bagging_fraction": trial.suggest_float("bagging_fraction", 0.5, 1.0),
        "bagging_freq": trial.suggest_int("bagging_freq", 0, 5),
        "random_state": 42,
        "objective": "regression",
        "verbose": -1
    }

    model = LGBMRegressor(**params)
    model.fit(X_train_search, y_train_search)
    val_pred = model.predict(X_val_search)
    return mean_absolute_error(y_val_search, val_pred)

study = optuna.create_study(direction="minimize", sampler=optuna.samplers.TPESampler(seed=42))
study.optimize(objective, n_trials=50)

best_params = study.best_params
best_params.update({
    "objective": "regression",
    "random_state": 42,
    "verbose": -1
})
print("✅ The TPE search yields the optimal parameters：")
for k, v in best_params.items():
    print(f"{k}: {v}")

true_prices, pred_prices, pred_dates = [], [], []

for i in range(start_forecast_index, len(df)):
    train_df = df.iloc[:i]
    test_df = df.iloc[i:i + 1]

    X_train = train_df[feature_cols].values
    y_train = train_df['Hogprice'].values
    X_test = test_df[feature_cols].values
    y_test = test_df['Hogprice'].values[0]

    model = LGBMRegressor(**best_params)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)[0]

    pred_prices.append(pred)
    true_prices.append(y_test)
    pred_dates.append(test_df['date'].values[0])

true_prices = np.array(true_prices)
pred_prices = np.array(pred_prices)
print("\nModel evaluation results：")
print("R2:", r2_score(true_prices, pred_prices))
print("MAE:", mean_absolute_error(true_prices, pred_prices))
print("RMSE:", np.sqrt(mean_squared_error(true_prices, pred_prices)))
print("MAPE:", mean_absolute_percentage_error(true_prices, pred_prices))

plt.figure(figsize=(10, 5))
plt.plot(pred_dates, true_prices, label="True Price")
plt.plot(pred_dates, pred_prices, label="Predicted Price")
plt.title(f"LightGBM Forecast (Future {n_forecast} steps - TPE Optimized)")
plt.xlabel("Date")
plt.ylabel("Price")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("lgb_forecast_tpe_optimized.png")
plt.show()

result_df = pd.DataFrame({
    "Date": pred_dates,
    "TruePrice": true_prices,
    "PredictedPrice": pred_prices,
    "AbsoluteError": np.abs(true_prices - pred_prices),
    "RelativeError(%)": np.abs(true_prices - pred_prices) / true_prices * 100
})
result_df.to_excel("lgb_forecast_results_tpe_optimized.xlsx", index=False)
print("\nThe rolling prediction result of the extended window has been saved：lgb_forecast_results_tpe_optimized.xlsx")

import json
with open("best_params_tpe.json", "w") as f:
    json.dump(best_params, f, indent=4)
print("The optimal parameters have been saved as a JSON file：best_params_tpe.json")