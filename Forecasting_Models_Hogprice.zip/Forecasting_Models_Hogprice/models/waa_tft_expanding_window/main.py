import numpy as np
import pandas as pd
import torch
import json
import random
import os
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, Dataset, TensorDataset
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, mean_absolute_percentage_error
import time

df = pd.read_csv('data/raw data.csv')
df.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df['Hogprice_lag1'] = df['Hogprice'].shift(1)
df['Hogprice_lag2'] = df['Hogprice'].shift(2)
df['Hogprice_lag3'] = df['Hogprice'].shift(3)
df['year'] = df['Date'].dt.year
df['month'] = df['Date'].dt.month
df['weekofyear'] = df['Date'].dt.isocalendar().week
df['dayofweek'] = df['Date'].dt.dayofweek
df['all_features_avg'] = df.drop(columns=['Date', 'Hogprice']).mean(axis=1)
df.dropna(inplace=True)

feature_cols = [col for col in df.columns if col not in ['Date', 'Hogprice']]
X_raw = df[feature_cols].values
y_raw = df['Hogprice'].values  # target variable

time_cats = df[['year_index', 'month', 'weekofyear']].values.astype(int)
static_cats = df['year_index'].values.astype(int)

scaler_X = MinMaxScaler()
scaler_Y = StandardScaler()
X = scaler_X.fit_transform(X_raw)
y = scaler_Y.fit_transform(y_raw.reshape(-1, 1)).flatten()


def generate_splits(target='Hogprice'):
    y_raw = df[target].values
    y = scaler_Y.fit_transform(y_raw.reshape(-1, 1)).flatten()

    total_len = len(X)
    train_len = int(total_len * 0.8)

    def create(X_raw, Y_raw, T_raw, S_raw):
        x_data, y_data, time_data, static_data = [], [], [], []
        for i in range(len(X_raw)):
            year_index = S_raw[i].item()
            month = T_raw[i][1]
            week = T_raw[i][2]
            time_feat = np.array([year_index, month, week, min(i, 599)], dtype=int)
            assert len(time_feat) == 4

            x_data.append(X_raw[i])
            y_data.append(Y_raw[i])
            time_data.append(time_feat)
            static_data.append(year_index)

        x_data = np.expand_dims(np.array(x_data), axis=1)
        return (
            torch.tensor(x_data, dtype=torch.float32),
            torch.tensor(np.array(y_data), dtype=torch.float32),
            torch.tensor(np.array(time_data), dtype=torch.long),  # shape: (N,4)
            torch.tensor(np.array(static_data), dtype=torch.long)
        )

    train_data = create(X[:train_len], y[:train_len], time_cats[:train_len], static_cats[:train_len])
    print(f"Train data shapes: {train_data[0].shape}")

    # Generate test set
    test_start_idx = train_len
    test_end_idx = total_len
    if test_start_idx >= test_end_idx:
        raise ValueError(f"Test data has no samples. start_idx={test_start_idx}, end_idx={test_end_idx}")

    test_X = X[test_start_idx:test_end_idx]
    test_Y = y[test_start_idx:test_end_idx]
    test_TF = time_cats[test_start_idx:test_end_idx]
    test_SF = static_cats[test_start_idx:test_end_idx]

    if len(test_X) == 0:
        raise ValueError("The test set is empty. Please check the data partitioning parameters")

    test_data = create(test_X, test_Y, test_TF, test_SF)
    print(f"Test data shapes: {test_data[0].shape}")
    return {
        'train': train_data,
        'test': test_data
    }


class GRN(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.linear1 = torch.nn.Linear(input_dim, hidden_dim)
        self.elu = torch.nn.ELU()
        self.linear2 = torch.nn.Linear(hidden_dim, input_dim)
        self.gate = torch.nn.Sequential(torch.nn.Linear(input_dim, input_dim), torch.nn.Sigmoid())
        self.norm = torch.nn.LayerNorm(input_dim)

    def forward(self, x):
        residual = x
        x = self.linear1(x)
        x = self.elu(x)
        x = self.linear2(x)
        gate = self.gate(residual)
        return self.norm(gate * x + (1 - gate) * residual)


class VariableSelection(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.grn = GRN(input_dim, hidden_dim)
        self.softmax = torch.nn.Softmax(dim=-1)

    def forward(self, x, return_weights=False):
        weights = self.grn(x.mean(dim=1))
        weights = self.softmax(weights)
        return (x * weights.unsqueeze(1), weights) if return_weights else (x * weights.unsqueeze(1))


class InterpretableMultiHeadAttention(torch.nn.Module):
    def __init__(self, d_model, num_heads):
        super().__init__()
        assert d_model % num_heads == 0
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        self.q_linear = torch.nn.Linear(d_model, d_model)
        self.k_linear = torch.nn.Linear(d_model, d_model)
        self.v_proj = torch.nn.Linear(d_model, d_model)
        self.out_proj = torch.nn.Linear(d_model, d_model)

    def forward(self, x, return_attn=False):
        B, L, D = x.size()
        Q = self.q_linear(x).view(B, L, self.num_heads, self.d_k).transpose(1, 2)
        K = self.k_linear(x).view(B, L, self.num_heads, self.d_k).transpose(1, 2)
        V = self.v_proj(x).view(B, L, self.num_heads, self.d_k).transpose(1, 2)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / np.sqrt(self.d_k)
        attn = torch.softmax(scores, dim=-1)
        context = torch.matmul(attn, V).transpose(1, 2).contiguous().view(B, L, D)
        output = self.out_proj(context)
        return (output, attn) if return_attn else output


class StaticCovariateEncoder(torch.nn.Module):
    def __init__(self, num_static, hidden_dim):
        super().__init__()
        self.embedding = torch.nn.Embedding(num_static, hidden_dim)
        self.grn = GRN(hidden_dim, hidden_dim)

    def forward(self, x):
        x = self.embedding(x)
        return self.grn(x)


class QuantileLoss(torch.nn.Module):
    def __init__(self, quantiles, weights=None):
        super().__init__()
        self.quantiles = quantiles
        self.weights = weights if weights else [1.0] * len(quantiles)

    def forward(self, preds, target):
        if preds.ndim == 1 or preds.shape[1] == 1:
            preds = preds.squeeze()
            errors = target - preds
            q = self.quantiles[0]
            loss = torch.max((q - 1) * errors, q * errors)
            return torch.mean(loss)
        elif preds.shape[1] != len(self.quantiles):
            raise ValueError(f"Expected preds.shape[1] == {len(self.quantiles)}, got {preds.shape}")
        losses = []
        for i, q in enumerate(self.quantiles):
            errors = target - preds[:, i]
            loss = torch.max((q - 1) * errors, q * errors).unsqueeze(1)
            losses.append(self.weights[i] * loss)
        return torch.mean(torch.sum(torch.cat(losses, dim=1), dim=1))


class WAA_TFT(torch.nn.Module):
    def __init__(self, input_dim, T, hidden_dim=64, attn_heads=2, dropout=0.1, n_layers=2, num_static=10, lookback=1):
        super().__init__()
        self.input_dim = input_dim
        self.lookback = lookback

        self.input_proj = torch.nn.Linear(self.lookback * input_dim, hidden_dim)

        if lookback > 1:
            self.var_select = VariableSelection(self.lookback * input_dim, hidden_dim)
        else:
            self.var_select = None

        self.year_emb = torch.nn.Embedding(10, hidden_dim)
        self.month_emb = torch.nn.Embedding(13, hidden_dim)
        self.week_emb = torch.nn.Embedding(53, hidden_dim)
        self.timeidx_emb = torch.nn.Embedding(600, hidden_dim)

        self.static_encoder = StaticCovariateEncoder(num_static, hidden_dim)
        self.lstm = torch.nn.LSTM(hidden_dim, hidden_dim, batch_first=True)
        self.dropout = torch.nn.Dropout(dropout)
        self.grn_stack = torch.nn.ModuleList([GRN(hidden_dim, hidden_dim) for _ in range(n_layers)])
        self.attn = InterpretableMultiHeadAttention(hidden_dim, attn_heads)
        self.output = torch.nn.Linear(hidden_dim, len([0.1, 0.5, 0.9]))

    def forward(self, x_seq, time_feat, static_feat, return_attn=False):
        if self.lookback > 1:
            batch_size = x_seq.size(0)
            if x_seq.size(1) < self.lookback:
                padding = torch.zeros(batch_size, self.lookback - x_seq.size(1), x_seq.size(2),
                                      device=x_seq.device, dtype=x_seq.dtype)
                x_seq = torch.cat([padding, x_seq], dim=1)

            lookback_data = x_seq[:, -self.lookback:, :]
            lookback_data = lookback_data.reshape(batch_size, -1)

            if return_attn:
                x, var_weights = self.var_select(lookback_data.unsqueeze(1), return_weights=True)
                x = x.squeeze(1)
                x = self.input_proj(x)
            else:
                x = self.var_select(lookback_data.unsqueeze(1))
                x = x.squeeze(1)
                x = self.input_proj(x)
                var_weights = None
        else:
            if return_attn:
                x, var_weights = self.var_select(x_seq, return_weights=True)
            else:
                x = self.var_select(x_seq)
                var_weights = None
            x = self.input_proj(x.squeeze(1))

        context = self.static_encoder(static_feat)
        x = x.unsqueeze(1)
        x, _ = self.lstm(x)
        for grn in self.grn_stack:
            x = self.dropout(grn(x))
        x = self.attn(x)
        x = x.mean(dim=1)
        if time_feat.size(1) != 4:
            batch_size = time_feat.size(0)
            time_index = torch.arange(0, batch_size, dtype=torch.long, device=time_feat.device).clamp(0, 599)
            time_feat = torch.cat([time_feat, time_index.unsqueeze(1)], dim=1)

        y = time_feat[:, 0]
        m = time_feat[:, 1]
        w = time_feat[:, 2]
        ti = time_feat[:, 3]
        time_emb = self.year_emb(y) + self.month_emb(m) + self.week_emb(w) + self.timeidx_emb(ti)
        x = x + time_emb + context
        out = self.output(x)
        return (out, var_weights) if return_attn else out


class MyDataset(Dataset):
    def __init__(self, X, Y, TF, SF):
        self.X, self.Y, self.TF, self.SF = X, Y, TF, SF

    def __len__(self):
        return len(self.X)

    def __getitem__(self, i):
        return self.X[i], self.Y[i], self.TF[i], self.SF[i]


class WAARealOptimizer:
    def __init__(self, model_cls, fitness_fn, param_config, device='cpu', alpha=10, max_iter=50, pop_size=10):
        self.model_cls = model_cls
        self.fitness_fn = fitness_fn
        self.param_config = param_config
        self.device = device
        self.alpha = alpha
        self.max_iter = max_iter
        self.pop_size = pop_size
        self.param_names = list(param_config.keys())

    def init_population(self):
        population = []
        while len(population) < self.pop_size:
            ind = {}
            for k, v in self.param_config.items():
                if v['type'] == 'int':
                    ind[k] = random.randint(*v['range'])
                elif v['type'] == 'float':
                    ind[k] = round(random.uniform(*v['range']), 5)

            if 'hidden_dim' in ind and 'attn_heads' in ind:
                if ind['hidden_dim'] % ind['attn_heads'] != 0:
                    continue
            population.append(ind)
        return population

    def compute_weighted_center(self, pop, fitness):
        weights = 1 / (np.array(fitness) + 1e-6)
        weights /= weights.sum()
        center = {}
        for k in self.param_names:
            values = np.array([ind[k] for ind in pop])
            if self.param_config[k]['type'] == 'int':
                center[k] = int(np.sum(values * weights))
            else:
                center[k] = np.sum(values * weights)
        return center

    def mutate(self, center):
        while True:
            mutant = {}
            for k, v in self.param_config.items():
                if v['type'] == 'int':
                    val = int(center[k] + random.gauss(0, 1) * (v['range'][1] - v['range'][0]) * 0.1)
                    val = max(min(val, v['range'][1]), v['range'][0])
                elif v['type'] == 'float':
                    val = center[k] + random.gauss(0, 1) * (v['range'][1] - v['range'][0]) * 0.1
                    val = round(max(min(val, v['range'][1]), v['range'][0]), 5)
                mutant[k] = val

            if 'hidden_dim' in mutant and 'attn_heads' in mutant:
                if mutant['hidden_dim'] % mutant['attn_heads'] == 0:
                    return mutant
            else:
                return mutant

    def search(self, dataset):
        pop = self.init_population()
        best_score = float('inf')
        best_ind = None
        stall = 0

        for iter in range(self.max_iter):
            fitness = [self.fitness_fn(ind, dataset) for ind in pop]
            center = self.compute_weighted_center(pop, fitness)

            best_idx = int(np.argmin(fitness))
            if fitness[best_idx] < best_score:
                best_score = fitness[best_idx]
                best_ind = pop[best_idx]
                stall = 0
            else:
                stall += 1

            print(f"[WAA] Iter {iter + 1}: Best MAPE={best_score:.4f}, Best={best_ind}")
            if stall >= self.alpha:
                print(f"[WAA] Early stopping at iter {iter + 1} due to alpha={self.alpha}.")
                break

            pop = [self.mutate(center) for _ in range(self.pop_size)]

        with open("best_params_CEEMDAN.json", "w") as f:
            json.dump(best_ind, f, indent=2)

        return best_ind


def waa_fitness_fn(param_dict, dataset):
    model = dataset['model_cls'](
        input_dim=dataset['input_dim'], T=1,
        hidden_dim=int(param_dict['hidden_dim']),
        attn_heads=int(param_dict['attn_heads']),
        dropout=float(param_dict['dropout']),
        n_layers=int(param_dict['n_layers']),
        num_static=dataset['num_static'],
        lookback=int(param_dict['lookback'])
    ).to(dataset['device'])

    optim = torch.optim.AdamW(model.parameters(), lr=float(param_dict['learning_rate']))
    loss_fn = dataset['loss_fn']

    train_data = dataset['train_data']
    train_loader = DataLoader(
        MyDataset(*train_data),
        batch_size=int(param_dict['batch_size']),
        shuffle=True
    )

    model.train()
    for _ in range(5):
        for xb, yb, tfb, sfb in train_loader:
            xb, yb, tfb, sfb = xb.to(dataset['device']), yb.to(dataset['device']), tfb.to(dataset['device']), sfb.to(
                dataset['device'])
            pred = model(xb, tfb, sfb)
            loss = loss_fn(pred, yb)
            optim.zero_grad()
            loss.backward()
            optim.step()

    model.eval()
    train_preds, train_targets = [], []
    with torch.no_grad():
        for xb, yb, tfb, sfb in train_loader:
            xb, yb, tfb, sfb = xb.to(dataset['device']), yb.to(dataset['device']), tfb.to(dataset['device']), sfb.to(
                dataset['device'])
            pred = model(xb, tfb, sfb)
            train_preds.extend(pred[:, 1].cpu().numpy())
            train_targets.extend(yb.cpu().numpy())

    return mean_absolute_percentage_error(train_targets, train_preds)


def train_one_epoch(model, train_loader, optimizer, loss_fn, device):
    model.train()
    total_loss = 0
    for xb, yb, tfb, sfb in train_loader:
        xb, yb, tfb, sfb = xb.to(device), yb.to(device), tfb.to(device), sfb.to(device)
        pred = model(xb, tfb, sfb)
        loss = loss_fn(pred, yb)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.5)
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(train_loader)


param_config = {
    'hidden_dim': {'type': 'int', 'range': (8, 32)},
    'attn_heads': {'type': 'int', 'range': (1, 4)},
    'dropout': {'type': 'float', 'range': (0.01, 0.015)},
    'n_layers': {'type': 'int', 'range': (1, 6)},
    'batch_size': {'type': 'int', 'range': (16, 32)},
    'learning_rate': {'type': 'float', 'range': (0.001, 0.005)},
    'lookback': {'type': 'int', 'range': (3, 10)}
}

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

splits = generate_splits(target='Hogprice')
num_static = df['year_index'].max() + 1

train_len = len(splits['train'][0])
test_len = len(splits['test'][0])
print(f"Training set size: {train_len}, Test set size: {test_len}")

print("Starting WAA optimization for best hyperparameters...")
dataset_for_search = {
    'train_data': splits['train'],
    'input_dim': splits['train'][0].shape[2],
    'num_static': num_static,
    'model_cls': WAA_TFT,
    'loss_fn': QuantileLoss([0.3, 0.5, 0.9]),
    'device': device
}

optimizer = WAARealOptimizer(
    model_cls=WAA_TFT,
    fitness_fn=waa_fitness_fn,
    param_config=param_config,
    device=device,
    alpha=10,
    max_iter=30,
    pop_size=10
)
best_params = optimizer.search(dataset_for_search)
print("Optimization complete, best parameters:", best_params)
OPTIMAL_LOOKBACK = best_params['lookback']
print(f"Optimal lookback parameter: {OPTIMAL_LOOKBACK}")

print("Starting expanding window rolling prediction...")
start_time = time.time()

history_X_raw = X_raw[:train_len].tolist()
history_y_raw = y_raw[:train_len].tolist()
history_time = time_cats[:train_len].tolist()
history_static = static_cats[:train_len].tolist()

pred_prices = []
true_prices = []

training_times = []

epochs_per_step = 200

for i in range(test_len):
    iter_start_time = time.time()

    X_train_raw = np.array(history_X_raw)
    y_train_raw = np.array(history_y_raw)
    time_train = np.array(history_time)
    static_train = np.array(history_static)

    scaler_X_current = MinMaxScaler()
    X_train_scaled = scaler_X_current.fit_transform(X_train_raw)

    scaler_Y_current = StandardScaler()
    y_train_scaled = scaler_Y_current.fit_transform(y_train_raw.reshape(-1, 1)).flatten()

    X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32).unsqueeze(1)
    y_train_tensor = torch.tensor(y_train_scaled, dtype=torch.float32)
    time_train_tensor = torch.tensor(time_train, dtype=torch.long)
    static_train_tensor = torch.tensor(static_train, dtype=torch.long)

    train_dataset = TensorDataset(X_train_tensor, y_train_tensor, time_train_tensor, static_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=min(int(best_params['batch_size']), len(train_dataset)),
                              shuffle=True)

    model = WAA_TFT(
        input_dim=X_train_scaled.shape[1],
        T=1,
        hidden_dim=int(best_params['hidden_dim']),
        attn_heads=int(best_params['attn_heads']),
        dropout=float(best_params['dropout']),
        n_layers=int(best_params['n_layers']),
        num_static=num_static,
        lookback=OPTIMAL_LOOKBACK
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=float(best_params['learning_rate']))
    loss_fn = QuantileLoss([0.3, 0.5, 0.9])

    for epoch in range(epochs_per_step):
        train_loss = train_one_epoch(model, train_loader, optimizer, loss_fn, device)

    test_idx = train_len + i
    test_X_raw = X_raw[test_idx].reshape(1, -1)
    test_time = time_cats[test_idx].reshape(1, -1)
    test_static = np.array([static_cats[test_idx]])

    test_X_scaled = scaler_X_current.transform(test_X_raw)

    test_X_tensor = torch.tensor(test_X_scaled, dtype=torch.float32).unsqueeze(1).to(device)
    test_time_tensor = torch.tensor(test_time, dtype=torch.long).to(device)
    test_static_tensor = torch.tensor(test_static, dtype=torch.long).to(device)

    with torch.no_grad():
        model.eval()
        y_pred_scaled = model(test_X_tensor, test_time_tensor, test_static_tensor)[:, 1].item()

    y_pred = scaler_Y_current.inverse_transform([[y_pred_scaled]])[0][0]

    true_price = y_raw[test_idx]

    pred_prices.append(y_pred)
    true_prices.append(true_price)

    history_X_raw.append(X_raw[test_idx])
    history_y_raw.append(true_price)
    history_time.append(time_cats[test_idx])
    history_static.append(static_cats[test_idx])

    iter_time = time.time() - iter_start_time
    training_times.append(iter_time)

    if (i + 1) % 10 == 0 or i == test_len - 1:
        avg_time = np.mean(training_times[-10:]) if i >= 10 else iter_time
        remaining = (test_len - i - 1) * avg_time
        print(f"Completed {i + 1}/{test_len} steps - "
              f"Training set size: {len(history_X_raw)} - "
              f"Current step time: {iter_time:.2f}s - "
              f"Estimated remaining: {remaining / 60:.1f} minutes")

total_time = time.time() - start_time
print(f"Rolling prediction complete! Total time: {total_time / 60:.2f} minutes")

r2 = r2_score(true_prices, pred_prices)
mae = mean_absolute_error(true_prices, pred_prices)
rmse = np.sqrt(mean_squared_error(true_prices, pred_prices))
mape = mean_absolute_percentage_error(true_prices, pred_prices)

print("\nModel evaluation results:")
print(f"R²: {r2:.6f}")
print(f"MAE: {mae:.6f}")
print(f"RMSE: {rmse:.6f}")
print(f"MAPE: {mape:.6f}")

results = pd.DataFrame({
    'Date': df['Date'].iloc[train_len:train_len + test_len],
    'True_Price': true_prices,
    'Predicted_Price': pred_prices
})
results.to_csv("waa_tft_expanding_window_results.csv", index=False)
print("Prediction results saved to waa_tft_expanding_window_results.csv")

plt.figure(figsize=(14, 7))
plt.plot(results['Date'], results['True_Price'], 'b-', label='True Price', linewidth=2)
plt.plot(results['Date'], results['Predicted_Price'], 'r--', label='Predicted Price', linewidth=2)

plt.title(f'WAA-TFT Expanding Window Rolling Prediction Results (Lookback={OPTIMAL_LOOKBACK})', fontsize=16)
plt.xlabel('Date', fontsize=12)
plt.ylabel('Price', fontsize=12)
plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.7)
plt.xticks(rotation=45)
plt.tight_layout()

metrics_text = f"R²: {r2:.4f}\nMAE: {mae:.4f}\nRMSE: {rmse:.4f}\nMAPE: {mape:.4f}%"
plt.figtext(0.75, 0.15, metrics_text, bbox=dict(facecolor='white', alpha=0.5), fontsize=12)

plt.savefig("waa_tft_expanding_window_forecast.png", dpi=300)
print("Prediction chart saved as waa_tft_expanding_window_forecast.png")
plt.show()