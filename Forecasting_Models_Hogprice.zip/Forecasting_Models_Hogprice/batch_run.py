import subprocess

models = [
    "models/lstm_expanding_window/main.py",
    "models/waa_tft_expanding_window/main.py",
    "models/xgb_expanding_window/main.py",
    "models/lgb_expanding_window/main.py",
    "models/waa_lgb_expanding_window/main.py",
    "models/tpe_lgb_expanding_window/main.py",
    "models/bo_lgb_expanding_window/main.py",
    "models/rs_lgb_expanding_window/main.py"
]

print("🚩 Starting batch run for all 8 forecasting models...")

for model_script in models:
    print(f"\n✅ Running {model_script} ...")
    result = subprocess.run(["python", model_script])
    if result.returncode != 0:
        print(f"❌ Error occurred while running {model_script}")
    else:
        print(f"✅ Finished {model_script}")

print("\n🚩 All models executed.")
